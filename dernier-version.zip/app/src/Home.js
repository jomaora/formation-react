import React from 'react'

export default props => <h1>Welcome to my store!</h1>
