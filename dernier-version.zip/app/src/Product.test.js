import React from 'react'
import Product from './Product'
import { renderWithContext } from './test-utils'

it('renders without crashing', async () => {
  const product = {
    id: 'product-1',
    title: 'Product 1',
    image: 'image-1',
    price: 1337
  }
  const { container } = renderWithContext(<Product product={product} />)
  expect(container).toMatchSnapshot()
})
