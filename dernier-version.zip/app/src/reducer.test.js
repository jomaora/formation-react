import { reducer, initialState } from './reducer'
import { addToCart } from './actions'

it('should add product', () => {
  const product = { id: 'toto' }
  const state = reducer(initialState, addToCart(product, 2))
  expect(state.cart.products).toHaveProperty('toto')
  expect(state.cart.products.toto).toHaveProperty('quantity', 2)
  const state2 = reducer(state, addToCart(product, -2))
  expect(state2.cart.products).not.toHaveProperty('toto')
})

it('should add product twice', () => {
  const product = { id: 'toto' }
  const state = reducer(initialState, addToCart(product))
  expect(state.cart.products).toHaveProperty('toto')
  expect(state.cart.products.toto).toHaveProperty('quantity', 1)
  const state2 = reducer(state, addToCart(product))
  expect(state2.cart.products).toHaveProperty('toto')
  expect(state2.cart.products.toto).toHaveProperty('quantity', 2)
})
