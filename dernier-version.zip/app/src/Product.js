import React, { useRef } from 'react'
import { TProduct } from './types'
import { connect } from 'react-redux'
import { addToCart } from './actions'
import './Product.scss'

/* eslint-disable jsx-a11y/anchor-is-valid */

const animateImageMovingToCart = img => {
  // Add animated image moving to cart icon
  const bodyRect = document.body.getBoundingClientRect()
  const imageRect = img.getBoundingClientRect()
  const top = imageRect.top - bodyRect.top
  const right = bodyRect.right - imageRect.right
  const width = imageRect.width
  const height = imageRect.height
  const $image = img.cloneNode()
  $image.style.top = `${top}px`
  $image.style.right = `${right}px`
  $image.style.width = `${width}px`
  $image.style.height = `${height}px`
  $image.classList.add('moving-to-cart')
  document.body.appendChild($image)
  // Trigger move to top right in next tick
  setTimeout(() => {
    $image.style.top = '0px'
    $image.style.right = '0px'
    $image.style.width = '0px'
    $image.style.height = '0px'
  })
  // Watch for transition end
  let transitionendFired = false
  $image.addEventListener('transitionend', e => {
    // Event will fire 4 times, only catch one
    if (transitionendFired) {
      return
    }
    transitionendFired = true
    // Remove the whole element to cleanup DOM once animation is finished
    $image.remove()
  })
}

const Product = ({ product, addToCart }) => {
  const imgRef = useRef()
  return (
    <div className="card product">
      <div className="card-image">
        <img src={product.image} alt="" ref={imgRef} />
        <a
          className="btn-floating btn-large halfway-fab waves-effect waves-light red"
          onClick={() => {
            animateImageMovingToCart(imgRef.current)
            addToCart(product)
          }}
        >
          <i className="material-icons">add_shopping_cart</i>
        </a>
      </div>
      <div className="card-content">
        <span className="card-title">
          {product.title} ({product.price} €)
        </span>
      </div>
    </div>
  )
}

Product.propTypes = {
  product: TProduct.isRequired
}

const mapActionToProps = {
  addToCart
}

export default connect(
  null,
  mapActionToProps
)(Product)
