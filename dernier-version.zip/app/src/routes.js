import Home from './Home'
import ProductList from './ProductList'
import NotFound from './NotFound'
import { buildRoutes } from './named-routes'

export const namedRoutes = {
  home: '/',
  products: '/:category'
}

export const routes = buildRoutes(namedRoutes, [
  {
    name: 'home',
    exact: true,
    component: Home
  },
  {
    name: 'products',
    component: ProductList
  },
  {
    component: NotFound
  }
])
