import { useState, useEffect, useRef } from 'react'

export const useMount = fn => {
  useEffect(() => {
    fn()
  }, [])
}

export const useUnmount = fn => {
  useEffect(() => fn, [])
}

export const useMounted = () => {
  const mounted = useRef(false)
  useMount(() => (mounted.current = true))
  useUnmount(() => (mounted.current = false))
  return () => mounted.current
}

export const useLoadData = (load, inputs, initialValue = null) => {
  const [result, setResult] = useState(initialValue)
  const [isLoading, setIsLoading] = useState(true)
  const mounted = useMounted()

  useEffect(() => {
    setIsLoading(true)
    load(...inputs).then(result => {
      if (mounted()) {
        setIsLoading(false)
        setResult(result)
      }
    })
    return () => {
      if (mounted()) {
        setResult(initialValue)
      }
    }
  }, inputs)

  return [result, isLoading]
}
