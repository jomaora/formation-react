export const initialState = /* ImmutableJS: fromJS(...) */ {
  cart: {
    open: false,
    products: {}, // { [id]: { product: Product, quantity: number } }
    totalQuantity: 0
  },
  products: {
    loading: false,
    error: null,
    list: [] // [{ id: string, image: string, title: string, price: number }]
  }
}

export const reducer = (state, action) => {
  switch (action.type) {
    case 'TOGGLE_CART': {
      const open =
        typeof action.payload.open === 'boolean'
          ? action.payload.open
          : !state.cart.open

      // ImmutableJS:
      // return state.setIn(['cart', 'open'], open)

      if (open === state.cart.open) {
        return state
      }
      return {
        ...state,
        cart: {
          ...state.cart,
          open
        }
      }
    }

    case 'ADD_TO_CART': {
      if (action.payload.quantity === 0) {
        return state
      }

      /* ImmutableJS:
      const quantity = state.getIn(['cart', 'products', action.payload.product.id, 'quantity'])
      if (quantity) {
        const newQuantity = quantity + action.payload.quantity
        if (newQuantity === 0) {
          return state.deleteIn(['cart', 'products', action.payload.product.id])
        } else {
          return state.setIn(['cart', 'products', action.payload.product.id, 'quantity'], newQuantity)
        }
      } else {
        return state.setIn(['cart', 'products', action.payload.product.id], fromJS({
          product: action.payload.product,
          quantity: action.payload.quantity
        }))
      }
      */

      const products = { ...state.cart.products }
      let foundRow = products[action.payload.product.id]

      if (foundRow) {
        const quantity = foundRow.quantity + action.payload.quantity
        if (quantity === 0) {
          delete products[foundRow.product.id]
        } else {
          foundRow = {
            ...foundRow,
            quantity: foundRow.quantity + action.payload.quantity
          }
          products[foundRow.product.id] = foundRow
        }
      } else {
        products[action.payload.product.id] = {
          product: action.payload.product,
          quantity: action.payload.quantity
        }
      }

      return {
        ...state,
        cart: {
          ...state.cart,
          totalQuantity: state.cart.totalQuantity + action.payload.quantity,
          products
        }
      }
    }

    case 'FETCH_PRODUCTS_START':
      return {
        ...state,
        products: {
          ...state.products,
          loading: true,
          list: [],
          error: null
        }
      }
    case 'FETCH_PRODUCTS_SUCCESS':
      return {
        ...state,
        products: {
          ...state.products,
          loading: false,
          list: action.payload.list,
          error: null
        }
      }
    case 'FETCH_PRODUCTS_ERROR':
      return {
        ...state,
        products: {
          ...state.products,
          loading: false,
          list: [],
          error: action.payload.error
        }
      }

    default:
      return state
  }
}
