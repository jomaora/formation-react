import React, { useState } from 'react'

const Counter = props => {
  const [value, setValue] = useState(1)
  const incr = () => setValue(value + 1)
  return <button onClick={incr}>{value}</button>
}

export default Counter

/*
class Counter extends React.Component {
  state = {
    value: 1
  }

  render() {
    console.log('Counter#render')
    return React.createElement(
      'button',
      {
        onClick: () => {
          this.setState(state => ({
            value: state.value + 1
          }))
        }
      },
      this.state.value
    )
  }

  UNSAFE_componentWillMount() {
    console.log('Counter#componentWillMount')
  }

  componentDidMount() {
    console.log('Counter#componentDidMount')
    // accordion.on()
  }

  componentWillUnmount() {
    console.log('Counter#componentWillUnmount')
    // accordion.off()
  }

  UNSAFE_componentWillUpdate(nextProps, nextState) {
    console.log('Counter#componentWillUpdate')
    // accordion.off()
  }

  getSnapshotBeforeUpdate(prevProps, prevState) {
    console.log('Counter#getSnapshotBeforeUpdate')
    return null
  }

  componentDidUpdate(prevProps, prevState, snapshot) {
    console.log('Counter#componentDidUpdate')
    // accordion.on()
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    console.log('Counter#willReceiveProps')
  }

  shouldComponentUpdate(nextProps, nextState) {
    // PureComponent:
    // return !eql(this.state, nextState) || !eql(this.props, nextProps)
    console.log('Counter#shouldComponentUpdate', this.state, nextState)
    return true
  }
}
*/
