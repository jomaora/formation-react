import { listCategoryProducts } from './api'

/**
 * Flux standard action:
 * {
 *  type:     string,
 *  payload:  any?,
 *  error:    boolean?,
 *  meta:     object?
 * }
 */

export const toggleCart = (open = null) => ({
  type: 'TOGGLE_CART',
  payload: {
    open
  }
})

export const addToCart = (product, quantity = 1) => ({
  type: 'ADD_TO_CART',
  payload: {
    product,
    quantity
  }
})

export const fetchProducts = category => dispatch => {
  dispatch(startFetchProducts())
  listCategoryProducts(category)
    .then(list => dispatch(succeededFetchProducts(list)))
    .catch(err => dispatch(failedFetchProducts(err)))
}

const startFetchProducts = () => ({
  type: 'FETCH_PRODUCTS_START'
})

const succeededFetchProducts = list => ({
  type: 'FETCH_PRODUCTS_SUCCESS',
  payload: { list }
})

const failedFetchProducts = error => ({
  type: 'FETCH_PRODUCTS_ERROR',
  error: true,
  payload: { error }
})

/*
class Action {
  constructor(type, payload, meta = null, error = false) {
    this.type = type
    this.payload = payload
    this.meta = meta
    this.error = error
  }
}

class ErrorAction extends Action {
  constructor(type, payload, meta) {
    super(type, payload, meta, true)
  }
}

export class ToggleCartAction extends Action {
  constructor(open = null) {
    super('TOGGLE_CART', { open })
  }
}

dispatch(new ToggleCartAction(true))
*/
