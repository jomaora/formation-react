export const buildRoutes = (namedRoutes, routes) =>
  routes.map(route =>
    route.name || route.routes
      ? // 'name' or 'routes': return a new route object
        {
          ...route,
          path: route.path || namedRoutes[route.name], // keep provided path if defined
          routes: route.routes && buildRoutes(namedRoutes, route.routes) // browse sub-routes if applicable
        }
      : // otherwise, don't touch it
        route
  )

export const buildUrl = (namedRoutes, name, params = {}) =>
  namedRoutes[name].replace(
    /:[a-zA-Z0-9_]+/g,
    param => params[param.substring(1)]
  )
