import React from 'react'
import { fireEvent } from 'react-testing-library'
import App from './App'
import { MemoryRouter } from 'react-router-dom'
import { renderWithContext } from './test-utils'

jest.mock('./api', () => ({
  listCategoryProducts: async () => {
    return [
      {
        id: 'kitten-1',
        category: 'kitten',
        image: '',
        title: 'Test Kitten 1',
        price: 42
      }
    ]
  }
}))

it('renders without crashing', async () => {
  const { findByText, getByText, queryByText } = renderWithContext(<App />)
  expect(await findByText('Welcome to my store!')).toBeInTheDocument()
  const link = getByText('Kittens') // TODO get it in header only
  fireEvent.click(link)

  expect(queryByText('Chargement…')).toBeInTheDocument()
  expect(queryByText(/Test Kitten 1/)).not.toBeInTheDocument()
  expect(await findByText(/Test Kitten 1/)).toBeInTheDocument()
  expect(await findByText(/42 €/)).toBeInTheDocument()
})
