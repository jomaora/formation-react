import React, { useEffect } from 'react'
import Product from './Product'
import PropTypes from 'prop-types'
import { TProduct } from './types'
import { withRouter } from 'react-router-dom'
// import { useLoadData } from './hooks'
import { connect } from 'react-redux'
import { fetchProducts } from './actions'

const ProductList = ({ products }) => (
  <div className="row">
    {products.length === 0 && <p>Empty category</p>}
    {products.map(product => (
      <div className="col s3" key={product.id}>
        <Product product={product} />
      </div>
    ))}
  </div>
)

ProductList.propTypes = {
  products: PropTypes.arrayOf(TProduct).isRequired
}

/** /
class ConnectedProductList extends React.Component {
  state = { products: [], loading: true }
  mounted = false

  loadProducts() {
    if (this.mounted) {
      this.setState({ loading: true })
    }
    listCategoryProducts(this.props.match.params.category).then(list => {
      if (this.mounted) {
        this.setState({ products: list, loading: false })
      }
    })
  }

  componentDidMount() {
    this.mounted = true
    this.loadProducts()
  }

  getSnapshotBeforeUpdate(prevProps) {
    if (prevProps.match.params.category !== this.props.match.params.category) {
      this.setState({ products: [] })
    }
    return null
  }

  componentDidUpdate(prevProps) {
    if (prevProps.match.params.category !== this.props.match.params.category) {
      this.loadProducts()
    }
  }

  componentWillUnmount() {
    this.mounted = false
  }

  render() {
    if (this.state.loading) {
      return <p>Chargement…</p>
    }

    return <ProductList products={this.state.products} />
  }
}

/** /
const ConnectedProductList = ({ match }) => {
  const [products, loading] = useLoadData(
    listCategoryProducts,
    [match.params.category],
    []
  )

  if (loading) {
    return <p>Chargement…</p>
  }

  return <ProductList products={products} />
}
/**/

const ConnectedProductList = ({
  category,
  fetchProducts,
  loading,
  products
}) => {
  useEffect(() => {
    fetchProducts(category)
  }, [category])

  if (loading) {
    return <p>Chargement…</p>
  }

  return <ProductList products={products} />
}

ConnectedProductList.propTypes = {
  category: PropTypes.string.isRequired,
  fetchProducts: PropTypes.func.isRequired,
  loading: PropTypes.bool.isRequired,
  products: PropTypes.arrayOf(TProduct).isRequired
}

// ALWAYS withRouter(connect()(Component)), NEVER connect()(withRouter(Component))
// https://github.com/ReactTraining/react-router/blob/master/packages/react-router/docs/api/withRouter.md
export default withRouter(
  connect(
    (state, ownProps) => ({
      loading: state.products.loading,
      products: state.products.list,
      category: ownProps.match.params.category
    }),
    {
      fetchProducts
    }
  )(ConnectedProductList)
)
