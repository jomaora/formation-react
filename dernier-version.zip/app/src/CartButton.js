import React from 'react'
import { toggleCart } from './actions'
import { connect } from 'react-redux'
import PropTypes from 'prop-types'

/* eslint-disable jsx-a11y/anchor-is-valid */

export const CartButton = ({ productCount, onClick }) => (
  <a href="#" onClick={onClick}>
    <i className="material-icons left">shopping_cart</i> ({productCount})
  </a>
)

CartButton.propTypes = {
  onClick: PropTypes.func.isRequired
}

const mapStateToProps = state => ({
  productCount: state.cart.totalQuantity
})

const mapActionToProps = {
  onClick: () => toggleCart(true)
}

export default connect(
  mapStateToProps,
  mapActionToProps
)(CartButton)
