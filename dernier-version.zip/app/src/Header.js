import React from 'react'
import Menu from './Menu'
import PropTypes from 'prop-types'
import { TCategory } from './types'
import { Link } from 'react-router-dom'

const Header = ({ categories }) => (
  <nav>
    <div className="nav-wrapper">
      <Link to="/" className="brand-logo">
        Bazket
      </Link>
      <Menu categories={categories} />
    </div>
  </nav>
)

Header.propTypes = {
  categories: PropTypes.arrayOf(TCategory).isRequired
}

export default Header
