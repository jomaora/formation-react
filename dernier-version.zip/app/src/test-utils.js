import React from 'react'
import { render } from 'react-testing-library'
import { MemoryRouter } from 'react-router-dom'
import initStore from './store'
import { Provider } from 'react-redux'

export const renderWithContext = (element, initialState) => {
  const store = initStore(initialState)
  const wrapper = render(
    <Provider store={store}>
      <MemoryRouter>{element}</MemoryRouter>
    </Provider>
  )
  wrapper.store = store
  return wrapper
}
