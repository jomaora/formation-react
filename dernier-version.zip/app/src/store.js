import { createStore, applyMiddleware, compose } from 'redux'
import { reducer, initialState } from './reducer'
import thunkMiddleware from 'redux-thunk'

const logMiddleware = ({ getState, dispatch }) => next => action => {
  console.log(action)
  next(action)
}

const initStore = (_initialState = initialState) => {
  const middlewares = [logMiddleware, thunkMiddleware]

  // https://github.com/zalmoxisus/redux-devtools-extension#usage
  const composeEnhancers =
    typeof window === 'object' && window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__
      ? window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__({
          // Specify extension’s options like name, actionsBlacklist, actionsCreators, serialize...
        })
      : compose

  const enhancer = composeEnhancers(applyMiddleware(...middlewares))
  return createStore(reducer, _initialState, enhancer)
}

export default initStore

/* Sample async middleware:

export const fetchProducts = category => ({
  type: 'ASYNC',
  payload: {
    prefix: 'FETCH_PRODUCTS_',
    fn: () => listCategoryProducts(category)
  }
})

// cf. axiosMiddleware
const asyncMiddleware = ({ getState, dispatch }) => next => action => {
  if (action.type === 'ASYNC') {
    dispatch({
      type: action.payload.prefix + 'START'
    })
    action.payload
      .fn()
      .then(list =>
        dispatch({
          type: action.payload.prefix + 'SUCCESS',
          payload: { list }
        })
      )
      .catch(err =>
        dispatch({
          type: action.payload.prefix + 'ERROR',
          error: true,
          payload: { error: err }
        })
      )
  } else {
    next(action)
  }
}

const enhancer = applyMiddleware(…, asyncMiddleware)

useEffect(() => {
  dispatch(fetchProducts(match.params.category))
}, [match.params.category])
*/
