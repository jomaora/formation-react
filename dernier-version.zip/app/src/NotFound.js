import React from 'react'

export default () => <h1>Not found</h1>
