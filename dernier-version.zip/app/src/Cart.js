import React /*, { useState, useEffect }*/ from 'react'
import cx from 'classnames'
import { connect } from 'react-redux'
import PropTypes from 'prop-types'
import { toggleCart, addToCart } from './actions'
import { TProduct } from './types'
import './Cart.scss'

const Row = ({ product, quantity, onRemove, onChangeQuantity }) => (
  <tr>
    <td>
      <img
        src={product.image}
        alt=""
        className="circle"
        width="50"
        height="50"
      />
    </td>
    <td>
      <strong>{product.title}</strong>
    </td>
    <td>{product.price} €</td>
    <td>
      <input
        type="number"
        min="0"
        value={quantity}
        onChange={e => onChangeQuantity(e.target.value)}
      />
      <a className="btn-flat" href="#!" onClick={() => onRemove()}>
        <i className="material-icons">remove_shopping_cart</i>
      </a>
    </td>
    <td>{product.price * quantity} €</td>
  </tr>
)

Row.propTypes = {
  product: TProduct.isRequired,
  quantity: PropTypes.number.isRequired,
  onRemove: PropTypes.func.isRequired,
  onChangeQuantity: PropTypes.func.isRequired
}

const Cart = ({ open, onClose, onAddToCart, rows, totalQuantity }) => {
  /*
  const [open, setOpen] = useState(window.store.getState().cart.open)
  useEffect(() => {
    const unsubscribe = window.store.subscribe(() => {
      const state = window.store.getState()
      setOpen(state.cart.open)
    })
    return () => unsubscribe()
  })
  */

  const totalPrice = Object.keys(rows).reduce(
    (sum, k) => sum + rows[k].quantity * rows[k].product.price,
    0
  )

  return (
    <div className={cx('cart', { open })}>
      <div className="modal">
        <div className="modal-content">
          <h3 className="header">Your cart ({totalQuantity})</h3>

          <table className="striped">
            <thead>
              <tr>
                <th colSpan={2}>Product</th>
                <th>Unit Price</th>
                <th>Quantity</th>
                <th>Total Price</th>
              </tr>
            </thead>
            <tbody>
              {Object.keys(rows).map(k => (
                <Row
                  product={rows[k].product}
                  quantity={rows[k].quantity}
                  onChangeQuantity={qty =>
                    onAddToCart(rows[k].product, qty - rows[k].quantity)
                  }
                  onRemove={() =>
                    onAddToCart(rows[k].product, -rows[k].quantity)
                  }
                  key={k}
                />
              ))}
              <tr>
                <td colSpan={3}>&nbsp;</td>
                <td>{totalQuantity}</td>
                <td>
                  <strong>{totalPrice} €</strong>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div className="modal-overlay" onClick={() => onClose()} />
    </div>
  )
}

Cart.propTypes = {
  open: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired
}

const mapStateToProps = state => ({
  open: state.cart.open,
  // ImmutableJS:
  // open: state.getIn(['cart', 'open'])
  rows: state.cart.products,
  totalQuantity: state.cart.totalQuantity
})

const mapActionsToProps = {
  onClose: () => toggleCart(false),
  onAddToCart: addToCart
}

/*
const mapActionToProps = dispatch => {
  return {
    onClose: () => dispatch(toggleCart(false))
  }
}
*/

export default connect(
  mapStateToProps,
  mapActionsToProps
)(Cart)
