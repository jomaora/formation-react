import React from 'react'
import CartButton from './CartButton'
import PropTypes from 'prop-types'
import { TCategory } from './types'
import cx from 'classnames'
import { Link, withRouter, matchPath } from 'react-router-dom'
import { buildUrl } from './named-routes'
import { namedRoutes } from './routes'

export const Menu = ({ categories, location }) => (
  <ul id="nav-mobile" className="right hide-on-med-and-down">
    {categories.map(category => {
      // const path = `/${category}`
      const path = buildUrl(namedRoutes, 'products', { category: category.id })
      return (
        <li
          key={category.id}
          className={cx({ active: matchPath(location.pathname, { path }) })}
        >
          <Link to={path}>{category.label}</Link>
        </li>
      )
    })}
    <li>
      <CartButton />
    </li>
  </ul>
)

Menu.propTypes = {
  location: PropTypes.object,
  categories: PropTypes.arrayOf(TCategory).isRequired
}

export default withRouter(Menu)
