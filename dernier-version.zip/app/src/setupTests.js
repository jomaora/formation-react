// react-testing-library renders your components to document.body,
// this will ensure they're removed after each test.
import 'react-testing-library/cleanup-after-each'

// this adds jest-dom's custom assertions
import 'jest-dom/extend-expect'

// Sample usage of setupTests:
// global.localStore = …

// Monkey-patch console to specifically handle some behaviors
const _error = console.error
console.error = (message, ...rest) => {
  if (
    /When testing, code that causes React state updates should be wrapped into act/.test(
      message
    )
  ) {
    console.info(
      '\u001b[2mIgnored error about act() (see kentcdodds/react-testing-library#343 and facebook/react#14853)\u001b[22m'
    )
    return
  }

  if (/Failed prop type/.test(message)) {
    throw new Error(message)
  }

  _error.call(this, message, ...rest)
}
