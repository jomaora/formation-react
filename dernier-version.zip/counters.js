// Render #1 (pas de state) value = 1
// Render #2 (state = 2)    value = 2
function Counter2(props) {
  const [value, setValue] = React.useState(1)
  return React.createElement(
    'button',
    {
      onClick: () => {
        setValue(value + 1)
      }
    },
    value
  )
}

class Counter extends React.Component {
  /*state = {
    value: 1
  }*/

  constructor(props) {
    super(props)
    this.state = {
      value: 1
    }
  }

  render() {
    console.log('Counter#render')
    return React.createElement(
      'button',
      {
        onClick: () => {
          this.setState(state => ({
            value: state.value + 1
          }))
        }
      },
      this.state.value
    )
  }

  UNSAFE_componentWillMount() {
    console.log('Counter#componentWillMount')
  }

  componentDidMount() {
    console.log('Counter#componentDidMount')
    // accordion.on()
  }

  componentWillUnmount() {
    console.log('Counter#componentWillUnmount')
    // accordion.off()
  }

  UNSAFE_componentWillUpdate(nextProps, nextState) {
    console.log('Counter#componentWillUpdate')
    // accordion.off()
  }

  getSnapshotBeforeUpdate(prevProps, prevState) {
    console.log('Counter#getSnapshotBeforeUpdate')
    return null
  }

  componentDidUpdate(prevProps, prevState, snapshot) {
    console.log('Counter#componentDidUpdate')
    // accordion.on()
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    console.log('Counter#willReceiveProps')
  }

  shouldComponentUpdate(nextProps, nextState) {
    // PureComponent:
    // return !eql(this.state, nextState) || !eql(this.props, nextProps)
    console.log('Counter#shouldComponentUpdate', this.state, nextState)
    return true
  }
}

function Root(props) {
  const [nbCounters, setNbCounter] = React.useState(props.children)

  return React.createElement(
    React.Fragment,
    {},
    React.createElement(Hello, { who: 'John' }),
    React.createElement(
      'button',
      {
        onClick: () => {
          setNbCounter(nbCounters + 1)
        }
      },
      'Add counter'
    ),
    Array(nbCounters)
      .fill()
      .map((undef, index) => React.createElement(Counter, { key: index }))
      .reverse()
  )
}

Root.defaultProps = {
  intialValueNbCounter: 1
}

class Hello extends React.Component {
  render() {
    return React.createElement(
      'div',
      { className: 'box' },
      React.createElement('span', {}, 'Hello'),
      ', ',
      React.createElement('strong', {}, this.props.who)
    )
  }
}

function render() {
  const element = React.createElement(Root, {}, 2)
  ReactDOM.render(element, document.getElementById('app'))
}

render()
