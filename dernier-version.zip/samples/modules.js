// modules

import obj from 'path/to/file.js'
import { toto as tata } from '...'
// file.js
export default { … }
export const toto = 42
function bidule () { … }

// commonjs

const obj = require('path/to/file.js')
// file.js
module.exports = { … }
