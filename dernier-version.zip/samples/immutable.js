/*
for (let i = 0; i < 10; i++) {}

array.map
array.filter
array.reduce
*/

const memoize = require('lodash/memoize')

x = {
  toto: 'tutu'
}

function destructive_modifier(obj, field, val) {
  obj[field] = val
  return obj
}

function modifier(obj, field, val) {
  console.log('modifier')
  if (obj[field] === val) {
    return obj
  }

  const clone = Object.assign({}, obj)
  clone[field] = val
  return clone
}

function eql(a, b) {
  return a === b
}

const _modifier = memoize(modifier)

const y = _modifier(x, 'toto', 'tata')
const z = _modifier(x, 'toto', 'tata')

console.log(eql(y, z))
