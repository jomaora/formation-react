```js
x => x + 1

function (x) {
  return x + 1
}
```

```js
(a, b) => a + b

function (a, b) {
  return a + b
}
```

```js
a => {
  a + 2
}

function (a) {
  a + 2 // oups, pas de return
}
```
