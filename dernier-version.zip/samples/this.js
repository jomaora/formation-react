'use strict'

const counter = {
  value: 1,
  incr() {
    this.value++
  },
  incrASAP() {
    setTimeout(() => {
      this.incr()
    }, 0)
  }
}

/*
counter.incrASAP()
setTimeout(function() {
  console.log(counter.value)
}, 10)
*/

// counter.incr = counter.incr.bind(counter)

/*
const o2 = { value: 42 }
counter.incr.call(o2)
console.log(counter.value)
console.log(o2.value)
*/

/*
setTimeout(counter.incr, 1000)
setTimeout(function() {
  console.log(this)
  console.log(counter.value)
  console.log(global.value)
}, 1500)
*/

/*
const incr2 = counter.incr
incr2()
// mode strict: TypeError
// mode sloppy: global.value = NaN (lol)
*/
